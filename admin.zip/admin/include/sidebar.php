  <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Doctors</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="doctor.php">Add Doctors</a></li>
              <li><a class="" href="managedoctor.php">Manage Doctors</a></li>
			  </ul>
          </li>
		  <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Users</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
			
              <li><a class="" href="manageusers.php">Manage Users</a></li>
                </ul>
          </li>
        <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_plus-box"></i>
                          <span>Products</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="product.php">Add Products</a></li>
              <li><a class="" href="manageproduct.php">Manage Product List</a></li>
            </ul>
          </li>
		 
		  

         
		  		  <li>
            <a class="" href="../index.php">
                          <i class="icon_lock"></i>
                          <span>Logout</span>

                      </a>

          </li>


        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->

   