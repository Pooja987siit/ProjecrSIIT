<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
<title>Skin Issues Identification and Treatment </title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cloud based Kitchen" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link rel="stylesheet" href="cart/assets/css/style.css">
 
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/galleryeffect.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/jquery.flipster.css">
		<link rel='stylesheet' href='css/dscountdown.css' type='text/css' media='all' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<link href="//fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Faster+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
 
</head>

<body>

<!-- banner -->
<div class="banner-w3lsa" id="home">

	<div class="container1">
		<div class="header-nav " id="mNavbar">
			<nav class="navbar navbar-default">
					<div class="navbar-header" >
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1><a  href="index.php" style="margin-top:18px;  font-size: 20px;"><span class="logo-c">SIIT</a></h1>
					</div>
					<!-- navbar-header -->
					<div class="collapse navbar-collapse " id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.php" class="hvr-underline-from-center active">Home</a></li>
							
							<li><a href="admin.php" class="hvr-underline-from-center ">Admin Login</a></li>
							<li><a href="doctor.php" class="hvr-underline-from-center scroll1">Doctor Login</a></li>
						    <li><a href="partner.php" class="hvr-underline-from-center scroll1">Product Partner Login</a></li>
						
						</ul>
					</div>
					<div class="clearfix"> </div>	
				</nav>

		</div>
		<div class="clearfix"></div>
		
